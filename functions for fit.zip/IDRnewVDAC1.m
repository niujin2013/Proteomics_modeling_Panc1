% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewVDAC1(t, x ) 
 global kdeg_VDAC1   ;  % = param() ;
 global  beta_prev ; 
 kdeg_pjnk =  beta_prev(1) ;
 
  i =6;  
  dx = zeros( i ,1) ;  

 % pjnk 
 dx(1) = kdeg_pjnk  - kdeg_pjnk .*x(1) ; 
 dx(2) = kdeg_pjnk  - kdeg_pjnk .*x(2) ; 
 dx(3) = kdeg_pjnk ; 
  
 %VDAC1
 dx(4) = 0; % kdeg_VDAC1 .*x(1)  - kdeg_VDAC1 .*x(4) ; 
 dx(5) = 0; % kdeg_VDAC1 .*x(2)  - kdeg_VDAC1 .*x(5) ; 
 dx(6) = kdeg_VDAC1.*x(3) - kdeg_VDAC1 .*x(6) ;  
  