% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewBCL2(t, x ) %BCL2 <-pp65&pSTAT3 & |-VDAC 
 global beta_prev; 
 global  pp65_BCL2 pSTAT3_BCL2 VDAC1_BCL2
 
 kdeg_irak=beta_prev(1) ; 
 x_IRAK4=beta_prev(2) ;
 kdeg_pjnk=beta_prev(3); 
 kdeg_pSTAT3 = beta_prev(4) ;
 pSTAT3_pJNK = beta_prev(5); 
 kdeg = beta_prev(6) ;
 LLM = beta_prev(7) ; 
 cIAP_P = beta_prev(8) ;
 pp65_ciap=  beta_prev(9) ;
 kdeg_VDAC1= beta_prev(10); 
 

 
  i =21 ;  
  dx = zeros( i ,1) ;  
 % irak4
 dx(1) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(1) ; 
 dx(2) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(2) ; 
 dx(3) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(3); 
 % pJNK 
 dx(4) = kdeg_pjnk  - kdeg_pjnk .*x(4) ; 
 dx(5) = kdeg_pjnk  - kdeg_pjnk .*x(5) ; 
 dx(6) = kdeg_pjnk ;   
 % pSTAT3 
 dx(7) = kdeg_pSTAT3 .* x(1) .*x(4) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(7) ; 
 dx(8) = kdeg_pSTAT3 .* x(2) .*x(5) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(8) ; 
 dx(9) = kdeg_pSTAT3 .* x(3) .*x(6) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(9) ;      
 %VDAC1
 dx(10) = 0; % kdeg_VDAC1 .*x(1)  - kdeg_VDAC1 .*x(4) ; 
 dx(11) = 0; % kdeg_VDAC1 .*x(2)  - kdeg_VDAC1 .*x(5) ; 
 dx(12) = kdeg_VDAC1.*x(6) - kdeg_VDAC1 .*x(12 ) ;
 
 % ciap 
 dx(16) = kdeg .*(1-LLM) - kdeg .*x(16) ; 
 dx(17) = kdeg .*(1-min(cIAP_P , LLM) )   - kdeg .*x(17) ; 
 dx(18) = kdeg .*(1-min(( LLM + cIAP_P), 0.98)  ) - kdeg .*x(18) ;  
 
 % pp65 
 dx(19) = kdeg .*(x(16).^pp65_ciap) - kdeg .*x(19) ; 
 dx(20) = kdeg .*x(17).^pp65_ciap  - kdeg .*x(20) ; 
 dx(21) = kdeg .*x(18).^pp65_ciap  - kdeg .*x(21) ; 
    
 % BCL2
 dx(13) = kdeg .*max(x(19).^pp65_BCL2, x(7).^pSTAT3_BCL2 ).*x(10) .^VDAC1_BCL2 - kdeg .*x(13);  
 dx(14) = kdeg .*max(x(20).^pp65_BCL2, x(8).^pSTAT3_BCL2 ).*x(11) .^VDAC1_BCL2- kdeg .*x(14) ; 
 dx(15) = kdeg .*max(x(21).^pp65_BCL2, x(9).^pSTAT3_BCL2 ).*x(12) .^VDAC1_BCL2 - kdeg .*x(15) ; 
  