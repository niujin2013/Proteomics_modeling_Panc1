% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewirak4(t, x ) 
 global kdeg_irak x_IRAK4 ; % = param() ;
  i =3 ;  
  dx = zeros( i ,1) ;  
 % irak4
 dx(1) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(1) ; 
 dx(2) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(2) ; 
 dx(3) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(3); 
  
  
  