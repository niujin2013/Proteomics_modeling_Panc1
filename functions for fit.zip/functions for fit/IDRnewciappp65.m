% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx =IDRnewciappp65 (t, x) 
global kdeg LLM pp65_ciap;  
 %ini
 cIAP_P=0; 
 i =6  ;  
 dx = zeros( i ,1) ; 
 % ciap 
 dx(1) = kdeg .*(1-LLM) - kdeg .*x(1) ; 
 dx(2) = kdeg .*(1-min(cIAP_P , LLM) )   - kdeg .*x(2) ; 
 dx(3) = kdeg .*(1-min(( LLM + cIAP_P), 0.98)  ) - kdeg .*x(3) ; 
 
 % pp65 
 dx(4) = kdeg .*x(1).^pp65_ciap - kdeg .*x(4) ; 
 dx(5) = kdeg .*x(2).^pp65_ciap - kdeg .*x(5) ; 
 dx(6) = kdeg .*x(3).^pp65_ciap - kdeg .*x(6) ; 
 
 
 
 
  

  