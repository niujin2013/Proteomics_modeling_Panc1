% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewpjnk(t, x ) 
 global kdeg_pjnk ;  % = param() ;
  i =3 ;  
  dx = zeros( i ,1) ; 
 
 % pjnk 
 dx(1) = kdeg_pjnk  - kdeg_pjnk .*x(1) ; 
 dx(2) = kdeg_pjnk  - kdeg_pjnk .*x(2) ; 
 dx(3) = kdeg_pjnk ; 
  
  
  