% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewpSTAT3(t, x ) % pSTAT3 <-IRAK4 & |- pJNK 
 global beta_prev; 
 global kdeg_pSTAT3 pSTAT3_pJNK ; % = param() ;
 kdeg_irak=beta_prev(1) ; 
 x_IRAK4=beta_prev(2) ;
 kdeg_pjnk=beta_prev(3); 
 
  i =9 ;  
  dx = zeros( i ,1) ;  
 % irak4
 dx(1) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(1) ; 
 dx(2) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(2) ; 
 dx(3) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(3); 
 % pJNK 
 dx(4) = kdeg_pjnk  - kdeg_pjnk .*x(4) ; 
 dx(5) = kdeg_pjnk  - kdeg_pjnk .*x(5) ; 
 dx(6) = kdeg_pjnk ;   
 % pSTAT3 
 dx(7) = kdeg_pSTAT3 .* x(1) .*x(4) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(7) ; 
 dx(8) = kdeg_pSTAT3 .* x(2) .*x(5) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(8) ; 
 dx(9) = kdeg_pSTAT3 .* x(3) .*x(6) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(9) ;  
 
  
  