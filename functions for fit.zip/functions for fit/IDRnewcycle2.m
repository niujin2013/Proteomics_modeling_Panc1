% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewcycle2(t, x ) % cCasp3  <- BAX;|-BCL2 ; <- ASPP2
 global beta_prev IC_1 IC_2 IC_3 ;   
 
 global ELYS_MA kapm0 cIAP_AP cIAP_apm BAX_AP;   
 
kdeg_irak	=	beta_prev	(1	);
x_IRAK4	=	beta_prev	(2	);
kdeg_pjnk	=	beta_prev	(3	);
kdeg_pSTAT3	=	beta_prev	(4	);
pSTAT3_pJNK	=	beta_prev	(5	);
kdeg	=	beta_prev	(6	);
LLM	=	beta_prev	(7	);
pp65_ciap	=	beta_prev	(8	);
kdeg_VDAC1	=	beta_prev	(9	);
pp65_BCL2	=	beta_prev	(10	);
pSTAT3_BCL2	=	beta_prev	(11	);
VDAC1_BCL2	=	beta_prev	(12	);
kdeg_ELYS	=	beta_prev	(13	);
ELYS_P	=	beta_prev	(14	);
fb_selfELYS	=	beta_prev	(15	);
kdeg_ASPP2	=	beta_prev	(16	);
kdeg_bax	=	beta_prev	(17	);
bax_pp65	=	beta_prev	(18	);
fb_self	=	beta_prev	(19	);

  i =58;  
  dx = zeros(i ,1) ;  
  
 % irak4
 dx(1) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(1) ; 
 dx(2) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(2) ; 
 dx(3) = kdeg_irak .*(1+x_IRAK4) - kdeg_irak .*x(3); 
 
 % pJNK 
 dx(4) = kdeg_pjnk  - kdeg_pjnk .*x(4) ; 
 dx(5) = kdeg_pjnk  - kdeg_pjnk .*x(5) ; 
 dx(6) = kdeg_pjnk ;  
 
 % pSTAT3 
 dx(7) = kdeg_pSTAT3 .* x(1) .*x(4) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(7) ; 
 dx(8) = kdeg_pSTAT3 .* x(2) .*x(5) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(8) ; 
 dx(9) = kdeg_pSTAT3 .* x(3) .*x(6) .^pSTAT3_pJNK  - kdeg_pSTAT3 .*x(9) ;  
    
 %VDAC1
 dx(10) = 0; 
 dx(11) = 0; 
 dx(12) = kdeg_VDAC1.*x(6) - kdeg_VDAC1 .*x(12 ) ;
 
 % ciap 
 dx(16) = kdeg .*(1-LLM) - kdeg .*x(16) ; 
 dx(17) = kdeg - kdeg .*x(17) ; 
 dx(18) = kdeg .*(1-LLM) - kdeg .*x(18) ;  
 
 % pp65 
 dx(19) = kdeg .*x(16).^pp65_ciap - kdeg .*x(19) ; 
 dx(20) = kdeg .*x(17).^pp65_ciap  - kdeg .*x(20) ; 
 dx(21) = kdeg .*x(18).^pp65_ciap  - kdeg .*x(21) ; 
    
 % BCL2
 dx(13) = kdeg .*max(x(19).^pp65_BCL2, x(7).^pSTAT3_BCL2 ).*x(10) .^VDAC1_BCL2 - kdeg .*x(13);  
 dx(14) = kdeg .*max(x(20).^pp65_BCL2, x(8).^pSTAT3_BCL2 ).*x(11) .^VDAC1_BCL2- kdeg .*x(14) ; 
 dx(15) = kdeg .*max(x(21).^pp65_BCL2, x(9).^pSTAT3_BCL2 ).*x(12) .^VDAC1_BCL2 - kdeg .*x(15) ; 
 
 %ELYS
 dx(22) = kdeg_ELYS   ./x(25)^fb_selfELYS- kdeg_ELYS  .*x(22) ; 
 dx(23) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(26)^fb_selfELYS - kdeg_ELYS  .*x(23) ; 
 dx(24) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(27)^fb_selfELYS - kdeg_ELYS  .*x(24) ;  
  % ELYS_feedback  
 dx(25) = kdeg_ELYS .* x(22) - kdeg_ELYS  .*x(25) ; 
 dx(26) = kdeg_ELYS  .*x(23) - kdeg_ELYS  .*x(26) ; 
 dx(27) = kdeg_ELYS  .*x(24) - kdeg_ELYS  .*x(27) ; 
 
 %ASPP2
 dx(28) = kdeg_ASPP2 .* x(22) - kdeg_ASPP2  .*x(28) ; 
 dx(29) = kdeg_ASPP2  .*x(23) - kdeg_ASPP2  .*x(29) ; 
 dx(30) = kdeg_ASPP2  .*x(24) - kdeg_ASPP2  .*x(30) ;  
 
 % BAX <- pp65 , but decreased over time ; %        decot = exp(-dec .*(t-TL).* (t>TL) ); 
  dx(34) = kdeg_bax .*x(19).^bax_pp65./x(37).^fb_self - kdeg_bax .*x(34) ; %.*x(4).*x(10)
  dx(35) = kdeg_bax .*x(20).^bax_pp65./x(38).^fb_self - kdeg_bax .*x(35) ; %.*max(1,x(5).^bax_pp65       ) 
  dx(36) = kdeg_bax .*x(21).^bax_pp65./x(39).^fb_self - kdeg_bax .*x(36) ;   
 % BAX self regulation feedback 
  dx(37)=kdeg_bax.*x(34) -kdeg_bax.*x(37) ; 
  dx(38)=kdeg_bax.*x(35) -kdeg_bax.*x(38); 
  dx(39)=kdeg_bax.*x(36) -kdeg_bax.*x(39); 
  
% cycles 
		kpl	= 	1.97E-02;
		Smax_b_ap	= 	7.006;
		SC50_b	= 	47.77;
		DT	= 	20.41;
		Smax_p_ap	= 	61.47;
		SC50_p	= 	95.45;
		gamma_p	= 	3.452;
		Kmax_p	= 	0.3303;
		KC50_p	= 	18.93;
		k12	= 	4.48E-02;
		k23	= 	0.1288;
		k31	= 	8.07E-02;
		LNmax	= 	7.426;
		kap	= 	2.18E-03;
		kdec_ma	= 	1.00;
        
        
        live0  = IC_1+IC_2+IC_3 ; %   !initial live cells 
        live_B = x(41) +x(42) +x(43)+ x(44)+ x(45) ; %  !total live cells :B
        live_P = x(47) +x(48) +x(49)+ x(50)+ x(51) ; %  !total live cells :P
        live_BP= x(53) +x(54) +x(55)+ x(56)+ x(57) ; %  !total live cells :C
        I0_B = log( LNmax * live0 ) -log( live_B ) ; 
        I0_P = log( LNmax * live0 ) -log( live_P ) ; 
        I0_BP= log( LNmax * live0 ) -log( live_BP) ; 
        
        ELYS_B = x(22);  ELYS_P = x(23);  ELYS_BP = x(24);   
        kma_B = (ELYS_B>1.0).*ELYS_MA ;  kma_P = ELYS_P.^3 *ELYS_MA; kma_BP = ELYS_BP.^3 *ELYS_MA;
        kap1_B =kap * ( x(16).^cIAP_AP )  ;
        kap1_P =kap * ( x(17).^cIAP_AP )  ;
        kap1_BP=kap * ( x(18).^cIAP_AP )  ;

       kapm_B =0; 


 %delay 1 of      ASPP2 on mitotic cell death  
 % ktau = 1.00 ./tau ; 
 dx(31) = kdeg_ASPP2.* (x(30) ) - kdeg_ASPP2 .* x(31) ; 
 dx(32) = kdeg_ASPP2.* (x(31) ) - kdeg_ASPP2 .* x(32) ; 
 dx(33) = kdeg_ASPP2.* (x(32) ) - kdeg_ASPP2 .* x(33) ;
 dx(40)= 0;  
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%ASPP2+, bax+0, bcl2-(if<0),ciap-,
  kapm_B =0;  
  kapm_P =kapm0.*x(31) ;
  kapm_BP=kapm0.*x(31).*x(36).^BAX_AP.*((x(15)<1)./x(15)+ ...
      (x(15)>=1).*1 )./x(18).^cIAP_apm  ;
          
% c G1:41,47,53
dx(41) = 2* k31 * x(43)- k12 *I0_B * x(41) -kap1_B * x(41) ;
dx(47) = 2* k31 * x(49)- k12 *I0_P * x(47) -kap1_P * x(47) ;
dx(53) = 2* k31 * x(55)- k12 *I0_BP* x(53) -kap1_BP* x(53) ;
% c S: 42,48,54    
dx(42) = k12 *x(41) *I0_B - k23 *x(42) -kap1_B * x(42) ;
dx(48) = k12 *x(47) *I0_P - k23 *x(48) -kap1_P * x(48) ;
dx(54) = k12 *x(53) *I0_BP- k23 *x(54) -kap1_BP* x(54) ;
% C G2M: 43,49,55 
dx(43) = k23* x(42)- k31 *x(43)                 -kap1_B *  x(43) ;
dx(49) = k23* x(48)- k31 *x(49) - kma_P * x(49) -kap1_P *  x(49) ;
dx(55) = k23* x(54)- k31 *x(55) - kma_BP* x(55) -kap1_BP*  x(55) ;
% C arrested M:44,50,56
dx(44) = kma_B * x(43) - kpl* x(44)  -kapm_B * x(44) ;
dx(50) = kma_P * x(49) - kpl* x(50)  -kapm_P * x(50) ;
dx(56) = kma_BP* x(55) - kpl* x(56)  -kapm_BP* x(56) ;
% C polyploidy:45,51,57     
dx(45) = kpl * x(44)  -kpl * x(45) ; 
dx(51) = kpl * x(50)  -kpl * x(51) ; 
dx(57) = kpl * x(56)  -kpl * x(57) ;       
% c Apoptosis:46,52,58
dx(46) = kap1_B * ( x(41)+x(42)+x(43))                -kap * x(46) ; 
dx(52) = kap1_P * ( x(47)+x(48)+x(49)) +x(50) *kapm_P -kap * x(52) ; 
dx(58) = kap1_BP* ( x(53)+x(54)+x(55)) +x(56) *kapm_BP-kap * x(58) ;  
 
  
  