% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewbax(t, x) 
 global beta_prev ; 
 global kdeg_bax bax_pp65 fb_self  ; % = param() ; 
  kdeg = beta_prev(1) ;
  LLM = beta_prev(2) ; 
  cIAP_P = 0 ;
  pp65_ciap = beta_prev(3) ;
  
 %ini
 i =12 ;  
 dx = zeros( i ,1) ; 
 % ciap 
 dx(1) = kdeg .*(1-LLM) - kdeg .*x(1) ; 
 dx(2) = kdeg .*(1-min(cIAP_P , LLM) )   - kdeg .*x(2) ; 
 dx(3) = kdeg .*(1-min(( LLM + cIAP_P), 0.98)  ) - kdeg .*x(3) ;  
 % pp65 |-ciap 
 dx(4) = kdeg .*x(1).^pp65_ciap - kdeg .*x(4) ; 
 dx(5) = kdeg .*x(2).^pp65_ciap - kdeg .*x(5) ; 
 dx(6) = kdeg .*x(3).^pp65_ciap - kdeg .*x(6) ; 
 % BAX <- pp65 , but decreased over time ; %        decot = exp(-dec .*(t-TL).* (t>TL) ); 
  dx(7) = kdeg_bax .*x(4).^bax_pp65./x(10).^fb_self - kdeg_bax .*x(7) ; %.*x(4).*x(10)
  dx(8) = kdeg_bax .*x(5).^bax_pp65./x(11).^fb_self - kdeg_bax .*x(8) ; %.*max(1,x(5).^bax_pp65       ) 
  dx(9) = kdeg_bax .*x(6).^bax_pp65./x(12).^fb_self - kdeg_bax .*x(9) ; 
  % BAX self regulation feedback 
  dx(10)=kdeg_bax.*x(7) -kdeg_bax.*x(10) ; 
  dx(11)=kdeg_bax.*x(8) -kdeg_bax.*x(11); 
  dx(12)=kdeg_bax.*x(9) -kdeg_bax.*x(12);   
  

  
  
 