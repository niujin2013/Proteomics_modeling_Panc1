% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewASPP2(t, x ) % ASPP2
 global kdeg_ASPP2; %= param(1) ;
 global beta_prev ;
 kdeg_ELYS =beta_prev(1); 
 ELYS_P =beta_prev(2); 
 fb_selfELYS=beta_prev(3)  ; 
 
  i =9 ;  
  dx = zeros(i ,1) ; 
 
 % ELYS 
 dx(1) = kdeg_ELYS   ./x(4)^fb_selfELYS- kdeg_ELYS  .*x(1) ; 
 dx(2) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(5)^fb_selfELYS - kdeg_ELYS  .*x(2) ; 
 dx(3) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(6)^fb_selfELYS - kdeg_ELYS  .*x(3) ; 
 
  % ELYS_feedback  
 dx(4) = kdeg_ELYS .* x(1) - kdeg_ELYS  .*x(4) ; 
 dx(5) = kdeg_ELYS  .*x(2) - kdeg_ELYS  .*x(5) ; 
 dx(6) = kdeg_ELYS  .*x(3) - kdeg_ELYS  .*x(6) ; 
 
 %ASPP2 
 dx(7) = kdeg_ASPP2 .* x(1) - kdeg_ASPP2  .*x(7) ; 
 dx(8) = kdeg_ASPP2  .*x(2) - kdeg_ASPP2  .*x(8) ; 
 dx(9) = kdeg_ASPP2  .*x(3) - kdeg_ASPP2  .*x(9) ;  
  
  