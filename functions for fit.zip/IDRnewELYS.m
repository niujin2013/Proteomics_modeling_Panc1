% IDR1.m 
% Inputs:
% t - Time variable: not used here because our equation 
%     is independent of time, or 'autonomous'.
% x - Independent variable 

% Output:
% dx - First derivative:
function dx = IDRnewELYS(t, x ) % ELYS
 global kdeg_ELYS ELYS_P fb_selfELYS ; % = param() ;
  i =6 ;  
  dx = zeros( i ,1) ; 
 
 % ELYS 
 dx(1) = kdeg_ELYS   ./x(4)^fb_selfELYS- kdeg_ELYS  .*x(1) ; 
 dx(2) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(5)^fb_selfELYS - kdeg_ELYS  .*x(2) ; 
 dx(3) = kdeg_ELYS  .*(1+ ELYS_P*10 ) ./x(6)^fb_selfELYS - kdeg_ELYS  .*x(3) ; 
 
  % ELYS_feedback  
 dx(4) = kdeg_ELYS .* x(1) - kdeg_ELYS  .*x(4) ; 
 dx(5) = kdeg_ELYS  .*x(2) - kdeg_ELYS  .*x(5) ; 
 dx(6) = kdeg_ELYS  .*x(3) - kdeg_ELYS  .*x(6) ; 
  
  
  